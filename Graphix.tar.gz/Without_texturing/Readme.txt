Sources:
Ranveer Aggarwal
Base code from triangles assignment
